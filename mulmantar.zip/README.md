# mulmantar-chrome
A Chrome extension that shows the Sikh Mul Mantar on every new tab
